//
//  ViewController.swift
//  Practica5_Assets
//
//  Created by Alumno on 9/1/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImgSegundaImagen: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
    
    ImgSegundaImagen.image = UIImage(named: "Chayanne2")
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

